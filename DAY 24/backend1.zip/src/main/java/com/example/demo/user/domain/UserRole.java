package com.example.demo.user.domain;

public class UserRole {

}
